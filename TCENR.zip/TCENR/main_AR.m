clear
clc
close all
%--------------------------------------------------------------------------
load('AR_DAT.mat');

%--------------------------------------------------------------------------
param.maxIter = 5;
%--------------------------------------------------------------------------
Tr_DAT   =   double(NewTrain_DAT);
trls     =   trainlabels;
Tt_DAT   =   double(NewTest_DAT);
ttls     =   testlabels;

train_tol= size(Tr_DAT,2);
test_tol = size(Tt_DAT,2);
%--------------------------------------------------------------------------
eigen_dim = 54;
%--------------------------------------------------------------------------
[disc_set,disc_value,Mean_Image]  =  Eigenface_f(Tr_DAT,eigen_dim);
tr_dat  =  disc_set'*Tr_DAT;
tt_dat  =  disc_set'*Tt_DAT;
tr_dat = normc(tr_dat);
tt_dat = normc(tt_dat);
%--------------------------------------------------------------------------
id = zeros(1,test_tol);
X = tr_dat;
lambda_1 = 0.001;
lambda_2 = 0.0001;
lambda_3 = 0.0001;
mu = 0.01;
% dim = 54, lambda_1 = 0.001, lambda_2 = 0.0001, lambda_3 = 0.0001, mu = 0.01, acc = 85.98 
% dim = 120, lambda_1 = 0.001, lambda_2 = 0.00001, lambda_3 = 0.01, mu = 0.1, acc = 91.70
% dim = 300, lambda_1 = 0.001, lambda_2 = 0.001, lambda_3 = 0.001, mu = 0.01, acc = 94.85
param.lambda_1 = lambda_1;
param.lambda_2 = lambda_2;
param.mu = mu;
%--------------------------------------------------------------------------
class_num = length(unique(trls));
tr_sym_mat = zeros(length(trls));
tr_sym = zeros(length(trls));
XTmy = zeros(length(trls),1);

for ci = 1 : class_num   
    ind_ci = find(trls == ci);
    tr_descr_bar = zeros(size(X));
    tr_descr_bar(:,ind_ci) = X(:, ind_ci);
    ind_cil = find(trls ~= ci);
    tr_descr = zeros(size(X));
    tr_descr(:,ind_cil) = X(:, ind_cil);
    
    tr_sym = tr_sym + lambda_3 * (tr_descr' * tr_descr);
    tr_sym_mat = tr_sym_mat + (lambda_1+lambda_2) * (tr_descr_bar' * tr_descr_bar);
end
[~,n] = size(X);
temp_X = inv(X'*X+tr_sym_mat+tr_sym+mu/2*eye(n));
%-------------------------------------------------------------------------
parfor i = 1:test_tol
    y = tt_dat(:, i);
    alpha = TCENR(X, y, param, trls, temp_X);
    residuals = residual(X, y, alpha, trls);
    [~, index] = min(residuals);
    id(i) = index;
end
%-------------------------------------------------------------------------
cornum = sum(id == ttls);
acc = cornum / length(ttls);
fprintf('eigen_dim = %d, lambda_1 = %f, lambda_2 = %f, lambda_3 = %f, mu = %f, acc = %.2f\n', eigen_dim, lambda_1, lambda_2, lambda_3, mu, acc * 100);

