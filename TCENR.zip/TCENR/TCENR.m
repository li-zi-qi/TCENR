function alpha = TCENR(X, y ,param,trls, temp_X)
%--------------------------------------------------------------------------
    %参数设置
    mu = param.mu;
    maxIter = param.maxIter;
    lambda_1=param.lambda_1;
    lambda_2=param.lambda_2;
%--------------------------------------------------------------------------
    [~, n] = size(X);
    tol = 1e-5;
 
    alpha = zeros(n, 1);
    z = alpha;
    delta = alpha;
    class_num = length(unique(trls));
    XTmy = zeros(length(trls),1);
    for ci = 1 : class_num
        ind_ci = find(trls == ci);
        Xi = X(:,ind_ci);
        Xi_mean = mean(Xi,2);
        XTmy(ind_ci) = Xi'*(lambda_2*Xi_mean + lambda_1*y);
    end
%--------------------------------------------------------------------------   

        iter = 0;
        while iter<maxIter
            iter = iter + 1;

            z_k = z;
            alpha_k = alpha;

            % update alpha
            alpha = temp_X*(X'*y+XTmy+mu/2*z+delta/2);

            % update z
            z_temp = alpha-delta/mu;%计算更新z
            z = max(0,z_temp);%取更新z
%--------------------------------------------------------------------------
            leq1 = z-alpha;
            leq2 = z-z_k;
            leq3 = alpha-alpha_k;
            stopC1 = max(norm(leq1),norm(leq2));
            stopC = max(stopC1,norm(leq3));%长度的比较

            if stopC<tol || iter>=maxIter
                break;
            else
                delta = delta + mu*leq1;
            end
        end